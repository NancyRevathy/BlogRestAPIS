package com.springboot.blog.service.impl;

import com.springboot.blog.entity.Post;
import com.springboot.blog.exception.ResourceNotFoundException;
import com.springboot.blog.payload.PostDto;
import com.springboot.blog.payload.PostResponse;
import com.springboot.blog.repository.PostRepo;
import com.springboot.blog.service.PostService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PostServiceImpl implements PostService {

    @Autowired
    private PostRepo postRepository;

    @Autowired
    //Map one object into another object automatically
    private ModelMapper modelMapper;

    @Override
    public PostDto createPost(final PostDto postDto) {
        //convert DTO to entity
        final Post post = mapToEntity(postDto);
        final Post newPost = postRepository.save(post);

        //convert entity to DTO
        final PostDto postResponse = mapToDTO(newPost);
        return postResponse;
    }

    @Override
    public PostResponse getAllPosts(final int pageNo, final int pageSize, final String sortBy, final String sortDir) {

        final Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();

        //Create pageable instance
        //By default its ascending
        //final Pageable pageable = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
        // descending order
        final Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
        final Page<Post> posts = postRepository.findAll(pageable);

        //get content for page object
        final List<Post> listOfPost = posts.getContent();
        final List<PostDto> contents = listOfPost.stream().map(post -> mapToDTO(post)).collect(Collectors.toList());
        final PostResponse postResponse = new PostResponse();
        postResponse.setContent(contents);
        postResponse.setPageNo(posts.getNumber());
        postResponse.setPageSize(posts.getSize());
        postResponse.setTotalElements(posts.getTotalElements());
        postResponse.setTotalPages(posts.getTotalPages());
        postResponse.setLast(posts.isLast());

        return postResponse;

    }

    @Override
    public PostDto getPostById(final Long id) {
        Post post = postRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Post", "id", id));
        return mapToDTO(post);
    }

    public PostDto updatePost(final PostDto postDto, final Long id) {
        //get post by id from the database
        final Post post = postRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Post", "id", id));
        post.setTitle(postDto.getTitle());
        post.setDescription(postDto.getDescription());
        post.setContent(postDto.getContent());
        final Post updatePost = postRepository.save(post);
        return mapToDTO(updatePost);
    }

    @Override
    public void deletePostById(final Long id) {
        //get post by id from the database
        final Post post = postRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Post", "id", id));
        postRepository.delete(post);
    }

    //Convert Entity into DTO
    private PostDto mapToDTO(final Post post) {
        //Map one object into another object automatically(First arg(post) source and second arg(PostDto.class destination)
        final PostDto postDto = modelMapper.map(post, PostDto.class);
        /*final PostDto postDto = new PostDto();
        postDto.setId(post.getId());
        postDto.setTitle(post.getTitle());
        postDto.setDescription(post.getDescription());
        postDto.setContent(post.getContent());*/
        return postDto;
    }

    //Map to Entity
    private Post mapToEntity(final PostDto postDto) {
        //Map one object into another object automatically(First arg(postDto) source and second arg(Post.class destination)
        final Post post = modelMapper.map(postDto, Post.class);
       /* final Post post = new Post();
        post.setTitle(postDto.getTitle());
        post.setDescription(postDto.getDescription());
        post.setContent(postDto.getContent());*/
        return post;
    }

}
