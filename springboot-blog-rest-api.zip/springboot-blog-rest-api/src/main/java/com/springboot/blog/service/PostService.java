package com.springboot.blog.service;

import com.springboot.blog.payload.PostDto;
import com.springboot.blog.payload.PostResponse;

public interface PostService {

    PostDto createPost(final PostDto postDto);

    PostResponse getAllPosts(final int pageNumber, final int pageSize, final String sort, final String sortDir);

    PostDto getPostById(final Long id);

    PostDto updatePost(final PostDto postDto, final Long id);

    void deletePostById(final Long id);
}
