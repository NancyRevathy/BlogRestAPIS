package com.springboot.blog;

public class Main {
    public static void main(String args[]) {
        String v1 = "C:\\Argus/WMIQuery/";
        String v2 = v1.replaceAll("\\\\", "/");
        System.out.println(v1);
        System.out.println(v2);

        String s = "a\\a";

        String x = s.replaceAll("\\\\", "/");

        System.out.println(x);
    }
}
